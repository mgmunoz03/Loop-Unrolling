#include <stdio.h>

//Must declare loop iteration variable within for loop and only be 1 character (for now...)
void main(){
    int test[10];
    int  y = 2;
    for(int i = 0; i < 125; i++){
 int j;   test[j] = i * 5;  test[i] = 6 + i;
    i = 6;
    }
    
    for(int f = 0; f < 10; f++){
        printf("Data: %d \n", test[f]);
    }

int k;
    for(int s = 5; s < 27; s++){
        k += s; 
    }
}

